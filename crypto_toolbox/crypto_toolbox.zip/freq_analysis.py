import string
from collections import Counter
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox

import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

# English letter frequency (approximate, as percent)
ENGLISH_FREQ = {
    'A': 8.167, 'B': 1.492, 'C': 2.782, 'D': 4.253, 'E': 12.702,
    'F': 2.228, 'G': 2.015, 'H': 6.094, 'I': 6.966, 'J': 0.153,
    'K': 0.772, 'L': 4.025, 'M': 2.406, 'N': 6.749, 'O': 7.507,
    'P': 1.929, 'Q': 0.095, 'R': 5.987, 'S': 6.327, 'T': 9.056,
    'U': 2.758, 'V': 0.978, 'W': 2.360, 'X': 0.150, 'Y': 1.974, 'Z': 0.074,
}

LETTERS = list(string.ascii_uppercase)


def caesar_shift_text(text: str, shift: int) -> str:
    shifted_chars = []
    shift = shift % 26
    for ch in text:
        if 'A' <= ch <= 'Z':
            shifted_chars.append(chr((ord(ch) - ord('A') + shift) % 26 + ord('A')))
        elif 'a' <= ch <= 'z':
            shifted_chars.append(chr((ord(ch) - ord('a') + shift) % 26 + ord('a')))
        else:
            shifted_chars.append(ch)
    return ''.join(shifted_chars)


def compute_frequency(text: str) -> list[float]:
    text = text.upper()
    letters = [ch for ch in text if ch.isalpha()]
    total = len(letters)
    if total == 0:
        return [0.0] * 26
    counter = Counter(letters)
    return [(counter[l] / total) * 100.0 for l in LETTERS]


class FrequencyAnalysisApp:
    def __init__(self, root: tk.Tk | tk.Toplevel, initial_text: str = ''):
        self.root = root
        self.root.title('Frequency Analysis (Cipher matcher)')
        self.root.state('zoomed')

        self.base_text = ''
        self.original_text = ''
        self.current_text_view = ''
        self.column_keylen = None
        self.column_index = None
        self.column_selection = ''
        self.assembled_key = []
        self.undo_stack = []
        self.mode_var = tk.StringVar(value='vigenere')

        self._build_ui()
        self.update_mode()
        self._init_plot()

        if initial_text:
            self.text_widget.delete('1.0', 'end')
            self.text_widget.insert('1.0', initial_text)
            self.analyze()

    def _build_ui(self):
        top_frame = ttk.Frame(self.root)
        top_frame.pack(side='top', fill='x', padx=8, pady=8)

        label = ttk.Label(top_frame, text='Enter cipher text:')
        label.grid(row=0, column=0, sticky='w')

        self.text_widget = scrolledtext.ScrolledText(top_frame, width=70, height=10)
        self.text_widget.grid(row=1, column=0, columnspan=5, padx=0, pady=6)

        btn_analyze = ttk.Button(top_frame, text='Analyze', command=self.analyze)
        btn_analyze.grid(row=2, column=0, pady=4)

        btn_left = ttk.Button(top_frame, text='Shift ⬅', command=lambda: self.shift_text(-1))
        btn_left.grid(row=2, column=1, pady=4, padx=(10, 0))

        btn_right = ttk.Button(top_frame, text='Shift ➡', command=lambda: self.shift_text(1))
        btn_right.grid(row=2, column=2, pady=4, padx=(8, 0))

        btn_reset = ttk.Button(top_frame, text='Reset', command=self.reset_text)
        btn_reset.grid(row=2, column=3, pady=4, padx=(8, 0))

        btn_undo = ttk.Button(top_frame, text='Undo', command=self.undo)
        btn_undo.grid(row=2, column=4, pady=4, padx=(8, 0))

        ttk.Label(top_frame, text='Mode:').grid(row=3, column=0, sticky='e')
        caesar_btn = ttk.Button(top_frame, text='Use Caesar mode', command=lambda: self.set_mode('caesar'))
        caesar_btn.grid(row=3, column=1, sticky='w')
        vigenere_btn = ttk.Button(top_frame, text='Use Vigenere mode', command=lambda: self.set_mode('vigenere'))
        vigenere_btn.grid(row=3, column=2, sticky='w')

        ttk.Label(top_frame, text='Solve shift:').grid(row=4, column=0, sticky='e')
        self.solve_shift_var = tk.StringVar(value='0')
        self.solve_entry = ttk.Entry(top_frame, width=5, textvariable=self.solve_shift_var)
        self.solve_entry.grid(row=4, column=1, sticky='w', padx=(10, 0))

        self.validation_label = ttk.Label(top_frame, text='', foreground='red')
        self.validation_label.grid(row=4, column=2, columnspan=3, sticky='w', padx=(8, 0))

        btn_solve = ttk.Button(top_frame, text='Solve', command=self.solve_shift)
        btn_solve.grid(row=5, column=0, pady=4)

        self.btn_solve_col = ttk.Button(top_frame, text='Solve column', command=self.solve_column_shift)
        self.btn_solve_col.grid(row=5, column=1, pady=4, padx=(8, 0))

        btn_map = ttk.Button(top_frame, text='Show mapping', command=self.show_mapping)
        btn_map.grid(row=5, column=2, pady=4, padx=(8, 0))

        ttk.Label(top_frame, text='Key length n:').grid(row=6, column=0, sticky='e')
        self.keylen_entry = ttk.Entry(top_frame, width=5)
        self.keylen_entry.grid(row=6, column=1, sticky='w', padx=(10, 0))
        self.keylen_entry.insert(0, '1')

        ttk.Label(top_frame, text='Column i (0..n-1):').grid(row=6, column=2, sticky='e')
        self.column_entry = ttk.Entry(top_frame, width=5)
        self.column_entry.grid(row=6, column=3, sticky='w', padx=(8, 0))
        self.column_entry.insert(0, '0')

        self.show_col_button = ttk.Button(top_frame, text='Show column text', command=self.show_column_text)
        self.show_col_button.grid(row=6, column=4, pady=4, padx=(8, 0))

        ttk.Label(top_frame, text='Assembled key:').grid(row=7, column=0, sticky='e')
        self.key_entry = ttk.Entry(top_frame, width=30)
        self.key_entry.grid(row=7, column=1, columnspan=2, sticky='w', padx=(10, 0))
        self.key_entry.insert(0, '')
        self.key_entry.config(state='readonly')

        self.btn_add_key = ttk.Button(top_frame, text='Add shift to key', command=self.add_shift_to_key)
        self.btn_add_key.grid(row=7, column=3, pady=4, padx=(8, 0))

        self.btn_clear_key = ttk.Button(top_frame, text='Clear key', command=self.clear_key)
        self.btn_clear_key.grid(row=7, column=4, pady=4, padx=(8, 0))

        self.btn_column = ttk.Button(top_frame, text='Analyze column', command=self.analyze_column)
        self.btn_column.grid(row=5, column=3, pady=4, padx=(8,0))

        chart_frame = ttk.Frame(self.root)
        chart_frame.pack(side='top', fill='both', expand=True, padx=8, pady=8)

        self.figure, self.ax = plt.subplots(figsize=(10, 4))
        self.canvas = FigureCanvasTkAgg(self.figure, master=chart_frame)
        self.canvas_widget = self.canvas.get_tk_widget()
        self.canvas_widget.pack(fill='both', expand=True)

        bottom_frame = ttk.Frame(self.root)
        bottom_frame.pack(side='bottom', fill='x', padx=8, pady=6)

        self.info_label = ttk.Label(bottom_frame, text='Type or paste text, then click Analyze.')
        self.info_label.pack(side='left')

    def _init_plot(self):
        self.ax.clear()
        self.ax.set_title('Letter frequency: cipher (bars) + English (line)')
        self.ax.set_xlabel('Letter')
        self.ax.set_ylabel('Frequency (%)')
        self.ax.set_xticks(range(26))
        self.ax.set_xticklabels(LETTERS)
        self.ax.set_ylim(0, max(max(ENGLISH_FREQ.values()) * 1.2, 15))
        self.canvas.draw()

    def analyze(self):
        text = self.text_widget.get('1.0', 'end').strip()
        if not text:
            messagebox.showwarning('No input', 'Please enter cipher text to analyze.')
            return

        self.original_text = text
        self.base_text = text
        self.current_text_view = text
        self.column_selection = ''

        self._draw_frequency_from_base(0)

        # reset key assembly context when full reanalysis is started
        self.column_keylen = None
        self.column_index = None
        self.assembled_key = []
        self._update_key_display()

        self.info_label.config(text=f'Cipher text length {len(text)} chars, alphabetic {sum(ch.isalpha() for ch in text)} letters.')

    def analyze_column(self):
        text = self.text_widget.get('1.0', 'end').strip()
        if not text:
            messagebox.showwarning('No input', 'Please enter cipher text to analyze.')
            return

        try:
            key_len = max(1, int(self.keylen_entry.get()))
            col_idx = int(self.column_entry.get())
        except ValueError:
            messagebox.showwarning('Invalid input', 'Key length and column must be integers.')
            return

        if key_len < 1 or col_idx < 0 or col_idx >= key_len:
            messagebox.showwarning('Invalid input', 'Column index must be between 0 and key length - 1.')
            return

        sanitized = ''.join(ch for ch in text.upper() if ch.isalpha())
        selected = sanitized[col_idx::key_len]

        if not selected:
            messagebox.showinfo('Empty subset', 'No letters in chosen column; check key length or text.')
            return

        freq = compute_frequency(selected)
        self._draw_frequency(freq)
        self.column_selection = selected
        self.current_text_view = selected

        # if keylen changed in this analysis, reset assembled key state
        if self.column_keylen != key_len:
            self.assembled_key = ['?' for _ in range(key_len)]
        self.column_keylen = key_len
        self.column_index = col_idx
        self._update_key_display()

        self.info_label.config(text=f'Column {col_idx} of key length {key_len} subset size {len(selected)}.')



    def show_column_text(self):
        if not self.base_text:
            messagebox.showinfo('Analyze first', 'Please analyze text first.')
            return

        if self.column_keylen is None or self.column_index is None:
            messagebox.showinfo('Select column', 'Please run Analyze column first.')
            return

        key_len = self.column_keylen
        col_idx = self.column_index

        if key_len <= 0 or col_idx < 0 or col_idx >= key_len:
            messagebox.showinfo('Invalid column', 'Column key length/index values are invalid.')
            return

        plaintext = self.base_text
        result_chars = []
        alpha_count = 0

        for ch in plaintext:
            if ch.isalpha():
                if alpha_count % key_len == col_idx:
                    result_chars.append(ch)
                else:
                    result_chars.append('*')
                alpha_count += 1
            else:
                result_chars.append(ch)

        self.text_widget.delete('1.0', 'end')
        self.text_widget.insert('1.0', ''.join(result_chars))
        self.info_label.config(text=f'Column {col_idx} shown, others masked with *.')

    def _update_key_display(self):
        display = ''.join(self.assembled_key) if self.assembled_key else ''
        self.key_entry.config(state='normal')
        self.key_entry.delete(0, 'end')
        self.key_entry.insert(0, display)
        self.key_entry.config(state='readonly')

    def _save_undo_state(self):
        self.undo_stack.append({
            'base_text': self.base_text,
            'current_text_view': self.current_text_view,
            'column_keylen': self.column_keylen,
            'column_index': self.column_index,
            'column_selection': self.column_selection,
            'assembled_key': list(self.assembled_key),
        })
        if len(self.undo_stack) > 3:
            self.undo_stack.pop(0)

    def undo(self):
        if not self.undo_stack:
            messagebox.showinfo('Undo', 'No changes to undo.')
            return

        state = self.undo_stack.pop()
        self.base_text = state['base_text']
        self.current_text_view = state['current_text_view']
        self.column_keylen = state['column_keylen']
        self.column_index = state['column_index']
        self.column_selection = state['column_selection']
        self.assembled_key = state['assembled_key']

        self.text_widget.delete('1.0', 'end')
        self.text_widget.insert('1.0', self.base_text)
        self._update_key_display()
        self._draw_frequency_from_base(0)
        self.info_label.config(text='Undid last action.')

    def set_mode(self, mode: str):
        self.mode_var.set(mode)
        self.update_mode()

    def update_mode(self):
        mode = self.mode_var.get()
        if mode == 'caesar':
            self.keylen_entry.config(state='disabled')
            self.column_entry.config(state='disabled')
            self.show_col_button.config(state='disabled')
            self.btn_column.config(state='disabled')
            self.btn_solve_col.config(state='disabled')
            self.btn_add_key.config(state='disabled')
            self.btn_clear_key.config(state='disabled')
            self.assembled_key = []
            self._update_key_display()
            self.info_label.config(text='Caesar mode: column controls disabled.')
        else:
            self.keylen_entry.config(state='normal')
            self.column_entry.config(state='normal')
            self.show_col_button.config(state='normal')
            self.btn_column.config(state='normal')
            self.btn_solve_col.config(state='normal')
            self.btn_add_key.config(state='normal')
            self.btn_clear_key.config(state='normal')
            self.info_label.config(text='Vigenere mode: full column tools enabled.')

    def clear_key(self):
        self._save_undo_state()
        self.assembled_key = ['?' for _ in range(self.column_keylen)] if self.column_keylen else []
        self._update_key_display()
        self.info_label.config(text='Assembled key cleared.')

    def add_shift_to_key(self):
        if self.column_keylen is None or self.column_index is None:
            messagebox.showinfo('Select column', 'Run Analyze column first, then choose a column.')
            return

        raw = str(self.solve_shift_var.get()).strip()
        if not raw.isdigit():
            self.validation_label.config(text='Invalid shift: please enter integer 0-25.')
            return

        self.validation_label.config(text='')
        self._save_undo_state()

        shift = int(raw) % 26
        key_letter = LETTERS[(26 - shift) % 26]

        if len(self.assembled_key) != self.column_keylen:
            self.assembled_key = ['?' for _ in range(self.column_keylen)]

        if self.column_index < 0 or self.column_index >= self.column_keylen:
            messagebox.showwarning('Invalid column index', 'Column index outside key length range.')
            return

        self.assembled_key[self.column_index] = key_letter
        self._update_key_display()
        self.info_label.config(text=f'Set key position {self.column_index} to {key_letter} (shift {shift}).')

    def shift_text(self, delta: int):
        if not self.current_text_view:
            messagebox.showinfo('Analyze first', 'Please click Analyze or Analyze column before shifting.')
            return

        try:
            delta_int = int(delta)
        except ValueError:
            self.validation_label.config(text='Shift value must be numeric')
            return

        shifted = caesar_shift_text(self.current_text_view, delta_int)
        self.current_text_view = shifted
        self._draw_frequency_from_text(shifted)
        self.text_widget.delete('1.0', 'end')
        self.text_widget.insert('1.0', shifted)
        self.validation_label.config(text='')

    def solve_shift(self):
        if not self.base_text:
            messagebox.showinfo('Analyze first', 'Please click Analyze first before solving.')
            return

        raw = str(self.solve_shift_var.get()).strip()
        if not raw.isdigit():
            self.validation_label.config(text='Invalid shift: please enter integer 0-25.')
            return

        self.validation_label.config(text='')
        solve_shift = int(raw) % 26
        solved_text = caesar_shift_text(self.base_text, solve_shift)

        self._save_undo_state()

        self.base_text = solved_text
        self.current_text_view = solved_text

        self.text_widget.delete('1.0', 'end')
        self.text_widget.insert('1.0', solved_text)

        self.info_label.config(text=f'Solved with shift {solve_shift}.')
        self._draw_frequency_from_text(solved_text)

    def solve_column_shift(self):
        if not self.base_text or self.column_keylen is None or self.column_index is None or not self.column_selection:
            messagebox.showinfo('Select column', 'Please run Analyze column first before solving this column.')
            return

        raw = str(self.solve_shift_var.get()).strip()
        if not raw.isdigit():
            self.validation_label.config(text='Invalid shift: please enter integer 0-25.')
            return

        self.validation_label.config(text='')
        solve_shift = int(raw) % 26
        decrypted_column = caesar_shift_text(self.column_selection, solve_shift)

        result_chars = []
        col_pos = 0
        alpha_count = 0

        for ch in self.base_text:
            if ch.isalpha():
                if alpha_count % self.column_keylen == self.column_index:
                    d = decrypted_column[col_pos]
                    if ch.isupper():
                        result_chars.append(d.upper())
                    else:
                        result_chars.append(d.lower())
                    col_pos += 1
                else:
                    result_chars.append(ch)
                alpha_count += 1
            else:
                result_chars.append(ch)

        self._save_undo_state()
        solved_text = ''.join(result_chars)
        self.base_text = solved_text
        self.current_text_view = decrypted_column
        
        self.text_widget.delete('1.0', 'end')
        self.text_widget.insert('1.0', solved_text)

        self._draw_frequency_from_text(decrypted_column)
        self.info_label.config(text=f'Solved column {self.column_index} (keylen {self.column_keylen}) with shift {solve_shift}.')

    def reset_text(self):
        self.solve_shift_var.set('0')
        self.validation_label.config(text='')
        self.undo_stack.clear()

        if self.original_text:
            self.base_text = self.original_text
            self.current_text_view = self.original_text
            self.column_selection = ''
            self.column_keylen = None
            self.column_index = None
            self.assembled_key = []
            self._update_key_display()

            self.text_widget.delete('1.0', 'end')
            self.text_widget.insert('1.0', self.original_text)
            self._draw_frequency_from_base(0)
            self.info_label.config(text='Reset to original ciphertext.')
        else:
            self.base_text = ''
            self.current_text_view = ''
            self.text_widget.delete('1.0', 'end')
            self._draw_frequency_from_text('')
            self.info_label.config(text='Type or paste text, then click Analyze.')

    def _draw_frequency(self, freq_values: list[float]):
        self.ax.clear()

        self.ax.bar(LETTERS, freq_values, color='#377eb8', alpha=0.7, label='Cipher frequency (estimated)')

        eng_values = [ENGLISH_FREQ[l] for l in LETTERS]
        self.ax.plot(LETTERS, eng_values, color='#ff7f00', marker='o', linestyle='-', linewidth=2, label='English frequency')

        self.ax.set_title('Letter frequency: cipher (bars) vs English (line)')
        self.ax.set_xlabel('Letter')
        self.ax.set_ylabel('Frequency (%)')
        self.ax.set_xticks(range(26))
        self.ax.set_xticklabels(LETTERS)

        max_y = max(max(freq_values, default=0), max(eng_values)) * 1.15
        self.ax.set_ylim(0, max(15, max_y))
        self.ax.legend()
        self.ax.grid(axis='y', alpha=0.3)
        self.canvas.draw()

    def _draw_frequency_from_base(self, shift: int):
        base_freq = compute_frequency(self.base_text)
        rotated = [base_freq[(i - shift) % 26] for i in range(26)]
        self._draw_frequency(rotated)

    def _draw_frequency_from_text(self, text: str):
        freq = compute_frequency(text)
        self._draw_frequency(freq)

    def show_mapping(self):
        if not self.base_text:
            messagebox.showinfo('No data', 'Analyze text first to see mapping.')
            return

        raw_shift = self.solve_shift_var.get().strip() if self.solve_shift_var.get() is not None else '0'
        if not raw_shift.isdigit():
            shift = 0
        else:
            shift = int(raw_shift) % 26

        mapping_text = '\n'.join(
            f'{plain} -> {LETTERS[(i + shift) % 26]}'
            for i, plain in enumerate(LETTERS)
        )

        win = tk.Toplevel(self.root)
        win.title(f'Letter mapping for shift {shift}')
        ttk.Label(win, text=f'Mapping for shift {shift}:', font=('Segoe UI', 10, 'bold')).pack(padx=12, pady=8)

        txt = scrolledtext.ScrolledText(win, width=24, height=14, wrap='none', font=('Consolas', 10))
        txt.pack(padx=12, pady=(0, 8))
        txt.insert('1.0', mapping_text)
        txt.config(state='disabled')

        ttk.Button(win, text='Close', command=win.destroy).pack(pady=(0, 12))


def main():
    root = tk.Tk()
    app = FrequencyAnalysisApp(root)
    root.mainloop()


if __name__ == '__main__':
    main()
